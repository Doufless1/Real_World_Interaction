﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    public enum Suit
    {
        Clubs,                  //value = 0
        Spades,                 //value = 1
        Diamonds,               //value = 2
        Hearts                  //value = 3
    }
}
